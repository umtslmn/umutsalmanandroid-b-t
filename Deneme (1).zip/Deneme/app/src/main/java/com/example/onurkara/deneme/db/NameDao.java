package com.example.onurkara.deneme.db;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import java.util.ArrayList;
import java.util.List;

@Dao
public interface NameDao{

    @Query("SELECT * FROM user WHERE name = :mName")
    Entity getCustomQuery(String mName);

    @Query("SELECT * FROM user")
    List<Entity> getEntity();

    @Insert
    void insert(Entity entiy);
}
