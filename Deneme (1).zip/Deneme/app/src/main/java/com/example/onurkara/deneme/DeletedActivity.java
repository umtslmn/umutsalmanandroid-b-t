package com.example.onurkara.deneme;

import android.app.SearchManager;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import com.example.onurkara.deneme.db.AppDatabase;
import com.example.onurkara.deneme.db.Entity;
import com.example.onurkara.deneme.ui.Adapter;
import com.example.onurkara.deneme.ui.ClickEvent;

import java.util.ArrayList;
import java.util.List;

public class DeletedActivity extends AppCompatActivity {

    private RecyclerView rv;
    private ArrayList<String> array;
    private AppDatabase db;
    private ArrayList<String> names;
    private ArrayList<Entity> entites;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deleted);

        rv = findViewById(R.id.recyclerview);
        db = AppDatabase.getDatabase(this);

        names = new ArrayList<>();
        names = getIntent().getStringArrayListExtra("deleted-items");
        entites = new ArrayList<>();

        List<Entity> dbElements = db.mDao().getEntity();

        for (int i = 0; i < names.size(); i++) {
            for (int j = 0; j < dbElements.size(); j++) {
                if (names.get(i).equals(dbElements.get(j).name)) {
                    entites.add(db.mDao().getCustomQuery(names.get(i)));
                    break;
                }
            }

        }


        Adapter adapter = new Adapter(this, entites, new ClickEvent() {
            @Override
            public void onItemClick(View v, int position) {
                Toast.makeText(DeletedActivity.this, "HOCAM SAYGILAR", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(Intent.ACTION_WEB_SEARCH);

                String term = entites.get(position).name;  // term which you want to search for
                intent.putExtra(SearchManager.QUERY, term);
                startActivity(intent);
            }
        });

        rv.setAdapter(adapter);
        rv.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));


    }
}
