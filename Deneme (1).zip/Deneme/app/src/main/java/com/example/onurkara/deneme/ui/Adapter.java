package com.example.onurkara.deneme.ui;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.onurkara.deneme.R;

import org.w3c.dom.Entity;
import org.w3c.dom.Text;

import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

    private LayoutInflater inflater;
    private ArrayList<com.example.onurkara.deneme.db.Entity> entityArrayList;
    private ClickEvent listener;


    public Adapter(Context ctx, ArrayList<com.example.onurkara.deneme.db.Entity> entityArrayList, ClickEvent listener){
        inflater = LayoutInflater.from(ctx);
        this.entityArrayList = entityArrayList;
        this.listener = listener;
    }

    public void removeItem(int position) {
        entityArrayList.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, entityArrayList.size());
    }

    @NonNull
    @Override
    public Adapter.ViewHolder onCreateViewHolder(@NonNull final ViewGroup viewGroup, int i) {
        final View masterView = inflater.inflate(R.layout.rv_item, viewGroup, false);

        final ViewHolder viewHolder = new ViewHolder(masterView);

        masterView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onItemClick(v, viewHolder.getPosition());
            }
        });
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter.ViewHolder viewHolder, int i) {
        viewHolder.tvEmail.setText(entityArrayList.get(i).mEmail);
        viewHolder.tvName.setText(entityArrayList.get(i).name);
        viewHolder.tvAddress.setText(entityArrayList.get(i).mAddress);
    }

    @Override
    public int getItemCount() {
        return entityArrayList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName;
        TextView tvAddress;
        TextView tvEmail;

        ViewHolder(@NonNull View itemView) {
            super(itemView);

            tvName = itemView.findViewById(R.id.name);
            tvAddress = itemView.findViewById(R.id.address);
            tvEmail = itemView.findViewById(R.id.email);
        }
    }
}
