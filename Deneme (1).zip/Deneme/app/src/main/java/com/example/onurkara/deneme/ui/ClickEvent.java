package com.example.onurkara.deneme.ui;

import android.view.View;

public interface ClickEvent {
    public void onItemClick(View v, int position);
}
