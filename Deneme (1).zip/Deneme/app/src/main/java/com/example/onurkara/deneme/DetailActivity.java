package com.example.onurkara.deneme;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.onurkara.deneme.db.AppDatabase;
import com.example.onurkara.deneme.db.Entity;

import java.util.ArrayList;
import java.util.List;

public class DetailActivity extends AppCompatActivity {

    private AppDatabase db;

    private TextView tvName;
    private TextView tvAddress;
    private TextView tvEmail;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        tvName = findViewById(R.id.name);
        tvAddress = findViewById(R.id.address);
        tvEmail = findViewById(R.id.email);

        db = AppDatabase.getDatabase(this);

        initEvent();
    }

    private void initEvent() {

        int position = getIntent().getExtras().getInt("position");

        List<Entity> list = db.mDao().getEntity();

        Entity entity = list.get(position);

        tvName.setText(entity.name);
        tvAddress.setText(entity.mAddress);
        tvEmail.setText(entity.mEmail);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
