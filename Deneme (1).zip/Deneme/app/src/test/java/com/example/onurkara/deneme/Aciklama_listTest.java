package com.example.onurkara.deneme;

import static org.junit.Assert.*;

public class Aciklama_listTest {

}